<?php
  // Define database connection constants
  define('NAME', 'images/logo.png');
  define('ADMINNAME', 'images/adminlogo.png');
  define('TAGLINE', 'images/tagline.png');
?>
