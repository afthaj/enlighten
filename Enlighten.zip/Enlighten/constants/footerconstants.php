<?php
  // Define database connection constants
  define('COPYRIGHT1', 'An eBusiness Solution by the 2nd Year Students of the University of Colombo School of Computing');
  define('COPYRIGHT2', 'Copyright &copy; 2011 All Right Reserved');
?>
